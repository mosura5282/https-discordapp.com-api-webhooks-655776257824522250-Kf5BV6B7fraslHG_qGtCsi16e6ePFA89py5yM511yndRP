from .tools import Tools

def setup(bot):
	bot.add_cog(Tools(bot))