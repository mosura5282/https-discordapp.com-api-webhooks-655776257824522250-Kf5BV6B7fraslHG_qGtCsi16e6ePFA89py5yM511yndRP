from .region import Region


def setup(bot):
    bot.add_cog(Region())
