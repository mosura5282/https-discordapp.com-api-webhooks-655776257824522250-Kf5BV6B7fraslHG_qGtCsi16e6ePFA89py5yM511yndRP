from .noflippedtables import NoFlippedTables


def setup(bot):
  bot.add_cog(NoFlippedTables(bot))
