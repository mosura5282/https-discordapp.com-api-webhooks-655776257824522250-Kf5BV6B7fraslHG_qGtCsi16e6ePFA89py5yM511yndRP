from .away import Away


def setup(bot):
    bot.add_cog(Away(bot))
