from .partycrash import PartyCrash


def setup(bot):
    bot.add_cog(PartyCrash(bot))
