from .pressf import PressF

def setup(bot):
    bot.add_cog(PressF(bot))
