from .blurplefy import Blurplefy


def setup(bot):
    bot.add_cog(Blurplefy(bot))
